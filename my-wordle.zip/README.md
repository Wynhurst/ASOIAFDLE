# My Wordle Clone (Vanilla JS + Vercel)

A simple Wordle-style puzzle game using vanilla JS and Vercel functions.

## Local Development
npm install -g vercel
vercel dev

## Deployment
Push to GitHub → Import into Vercel → Deploy
